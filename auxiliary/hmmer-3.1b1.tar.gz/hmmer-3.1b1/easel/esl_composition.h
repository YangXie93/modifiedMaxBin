extern int  esl_composition_BL62(double *f);
extern int  esl_composition_WAG (double *f);
extern int  esl_composition_SW34(double *f);
extern int  esl_composition_SW50(double *f);
